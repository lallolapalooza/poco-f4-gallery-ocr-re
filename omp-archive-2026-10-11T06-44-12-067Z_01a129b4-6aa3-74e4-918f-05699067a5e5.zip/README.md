# Session archive

Generated 2026-10-11T20:51:26.582Z from session `01a129b4-6aa3-74e4-918f-05699067a5e5`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

7 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (5)

- `CloudPath` — 69 entries, 237823 bytes
- `LocalPath` — 88 entries, 403413 bytes
- `NativeEngine` — 118 entries, 496445 bytes
- `Orchestration` — 86 entries, 523804 bytes
- `ViewLayer` — 120 entries, 527663 bytes

## Totals

37 files, 35445932 bytes.

Omitted:
- agents.json: live per-agent state was not observed by the archiving process
